# CIS-230-SP25 Template
This is the project template for CIS-230-SP25. It includes a solution structure with projects for Console, Library, API, and Tests.
