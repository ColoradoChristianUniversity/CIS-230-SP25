﻿namespace Client.Library;

public class Class1
{

}
