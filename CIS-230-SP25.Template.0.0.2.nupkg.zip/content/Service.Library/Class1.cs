﻿namespace Service.Library;

public class Class1
{

}
